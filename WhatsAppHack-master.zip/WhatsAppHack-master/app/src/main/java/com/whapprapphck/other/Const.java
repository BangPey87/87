package com.whapprapphck.other;

public interface Const {

    String UI_THREAD = "UI_THREAD";
    String IO_THREAD = "IO_THREAD";

    // Timer
    int SLEEP_TIME = 70;

    // TapJoy SDK
    String TAP_JOY_SDK_KEY  = "z93FTB00QzurhLvD0jGqcwECx8QQVy7rWtV4jpWXDqiB9nmtr9SFOfo7UCWm";
    String TAP_USER_ID  = "cfddc54c-1d34-433b-ab84-bbc3d231aa73";
    String TAP_OFFER_WALL  = "Offerwall";

}
