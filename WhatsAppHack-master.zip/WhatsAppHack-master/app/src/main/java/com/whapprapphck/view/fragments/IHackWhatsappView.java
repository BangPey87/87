package com.whapprapphck.view.fragments;

public interface IHackWhatsappView extends View {

    void showPopUpDialog();

    void setProgress(int progress);

}
