package com.whapprapphck.view.activities;


public interface ActivityCallback {

    void showOfferWall();

    void startFragmentHackWhatsApp();

}
