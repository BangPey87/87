package com.whapprapphck.presenter;

public interface Presenter {

    void onStop();

}
