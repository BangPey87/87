package com.whapprapphck.view.fragments;

public interface View {

    void showError(String error);
}
