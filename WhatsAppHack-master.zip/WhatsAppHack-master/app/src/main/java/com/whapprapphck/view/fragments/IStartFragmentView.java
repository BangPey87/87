package com.whapprapphck.view.fragments;


public interface IStartFragmentView extends View {

    void showFragment();

}
